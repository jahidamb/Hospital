$(document).ready(function(){
    $('#menu').slicknav(
		{
		duration: 1000,
		easingOpen: "easeOutBounce",
		}
	);
    $('.isotop-oveley > a').magnificPopup({type:'image'});
    $('.gallery-overley > a').magnificPopup({type:'image'});
    
    $('.testimonial').owlCarousel({
    loop:true,
    margin:5,
	autoplay:false,
    nav:false,
	dost:true,
	smartSpeed:1000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
    });
    $('.doctar').owlCarousel({
    loop:true,
    margin:5,
	autoplay:true,
    nav:false,
	dost:false,
	smartSpeed:1000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:4
        }
    }
    });
    $('.gallery').owlCarousel({
    loop:true,
    margin:5,
	autoplay:true,
    nav:true,
	dost:true,
	smartSpeed:1000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:4
        }
    }
    });
    
     $('.isotop-item').isotope({
        itemSelector: '.item',
        LayoutMode: 'fitRows'
    });
    $('.isotop ul li').on('click', function(e){
        $('.isotop ul li').removeClass('active');
        $(this).addClass('active');
        
        var selector = $(this).attr('data-filter');
        $('.isotop-item').isotope({
            filter: selector
        });
        return false;
    });
    $('.counter').counterUp({
        delay: 10,
        time: 1000
    });
    
});
$(document).ready(function(){
	
$('.scroll').on('click', function(e){
	$('html').animate({
		'scrollTop':0
	},1000);
	return false;
});
$(window).scroll(function(){
    var halcyan = $(window).scrollTop();
    if(halcyan>400){
        $('.scroll').slideDown(1000);
    }
    else{
        $('.scroll').slideUp(1000);
    }

});


$(window).on('load', function(){
    $('#preloder').delay(200).fadeOut(2000);
    $('.sk-three-bounce').fadeOut(1000);
});

    
});


    



